


class Numbers(object):

    def add(self, x ,y):
        return x+y

    def sub(self,x ,y):
        return x-y
