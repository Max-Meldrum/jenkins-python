Jekins python setup
============================
